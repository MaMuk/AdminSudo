<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Equipos',
  'LBL_TEAMS' => 'Equipos',
  'LBL_TEAM_ID' => 'Id de Equipo',
  'LBL_ASSIGNED_TO_ID' => 'Id de Usuario Asignado',
  'LBL_ASSIGNED_TO_NAME' => 'Usuario',
  'LBL_TAGS_LINK' => 'Etiquetas',
  'LBL_TAGS' => 'Etiquetas',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Fecha de Creación',
  'LBL_DATE_MODIFIED' => 'Última Modificación',
  'LBL_MODIFIED' => 'Modificado Por',
  'LBL_MODIFIED_ID' => 'Modificado Por Id',
  'LBL_MODIFIED_NAME' => 'Modificado por Nombre',
  'LBL_CREATED' => 'Creado Por',
  'LBL_CREATED_ID' => 'Creado Por Id',
  'LBL_DOC_OWNER' => 'Propietario del documento',
  'LBL_USER_FAVORITES' => 'Usuarios que Prefieren',
  'LBL_DESCRIPTION' => 'Descripción',
  'LBL_DELETED' => 'Eliminado',
  'LBL_NAME' => 'Nombre',
  'LBL_CREATED_USER' => 'Creado Por Usuario',
  'LBL_MODIFIED_USER' => 'Modificado Por Usuario',
  'LBL_LIST_NAME' => 'Nombre',
  'LBL_EDIT_BUTTON' => 'Editar',
  'LBL_REMOVE' => 'Quitar',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modificado por Nombre',
  'LBL_LIST_FORM_TITLE' => 'Sudo Audit Lista',
  'LBL_MODULE_NAME' => 'Sudo Audit',
  'LBL_MODULE_TITLE' => 'Sudo Audit',
  'LBL_MODULE_NAME_SINGULAR' => 'Sudo Audit',
  'LBL_HOMEPAGE_TITLE' => 'Mi Sudo Audit',
  'LNK_NEW_RECORD' => 'Crear Sudo Audit',
  'LNK_LIST' => 'Vista Sudo Audit',
  'LNK_IMPORT_SA_SUDOAUDIT' => 'Import Sudo Audit',
  'LBL_SEARCH_FORM_TITLE' => 'Buscar Sudo Audit',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Ver Historial',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Actividades',
  'LBL_SA_SUDOAUDIT_SUBPANEL_TITLE' => 'Sudo Audit',
  'LBL_NEW_FORM_TITLE' => 'Nuevo Sudo Audit',
  'LNK_IMPORT_VCARD' => 'Import Sudo Audit vCard',
  'LBL_IMPORT' => 'Import Sudo Audit',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Sudo Audit record by importing a vCard from your file system.',
  'LBL_MODULE_ID' => 'Module ID',
  'LBL_CREATED_BY_USER' => 'Created by user',
  'LBL_CREATED_BY_SUDO' => 'Created by sudo',
  'LBL_FIELD_NAME' => 'Field Name',
  'LBL_DATA_TYPE' => 'Data Type',
  'LBL_BEFORE_VALUE_STRING' => 'Before value string',
  'LBL_AFTER_VALUE_STRING' => 'After value string',
  'LBL_BEFORE_VALUE_TEXT' => 'Before value text',
  'LBL_AFTER_VALUE_TEXT' => 'After value text',
  'LBL_CREATED_BY_SUDO_USER_ID' => 'Created By Sudo (related User ID)',
  'sudo_parent_name' => 'Parent Record',
);