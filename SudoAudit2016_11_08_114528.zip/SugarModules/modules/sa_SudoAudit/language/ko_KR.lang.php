<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => '팀',
  'LBL_TEAMS' => '팀',
  'LBL_TEAM_ID' => '팀 ID',
  'LBL_ASSIGNED_TO_ID' => '지정 사용자 ID',
  'LBL_ASSIGNED_TO_NAME' => '지정자',
  'LBL_TAGS_LINK' => '태그',
  'LBL_TAGS' => '태그',
  'LBL_ID' => 'ID:',
  'LBL_DATE_ENTERED' => '생성일자:',
  'LBL_DATE_MODIFIED' => '수정일자:',
  'LBL_MODIFIED' => '수정자:',
  'LBL_MODIFIED_ID' => '수정자 ID',
  'LBL_MODIFIED_NAME' => '사용자명에 의해 수정',
  'LBL_CREATED' => '생성자',
  'LBL_CREATED_ID' => '생성자 ID',
  'LBL_DOC_OWNER' => '문서소유자',
  'LBL_USER_FAVORITES' => '사용자 즐겨 찾기',
  'LBL_DESCRIPTION' => '설명',
  'LBL_DELETED' => '삭제',
  'LBL_NAME' => '이름',
  'LBL_CREATED_USER' => '사용자에 의해 생성',
  'LBL_MODIFIED_USER' => '사용자에 의해 수정',
  'LBL_LIST_NAME' => '성명',
  'LBL_EDIT_BUTTON' => '수정하기',
  'LBL_REMOVE' => '제거하기',
  'LBL_EXPORT_MODIFIED_BY_NAME' => '이름으로 수정',
  'LBL_LIST_FORM_TITLE' => 'Sudo Audit 목록',
  'LBL_MODULE_NAME' => 'Sudo Audit',
  'LBL_MODULE_TITLE' => 'Sudo Audit',
  'LBL_MODULE_NAME_SINGULAR' => 'Sudo Audit',
  'LBL_HOMEPAGE_TITLE' => '나의 Sudo Audit',
  'LNK_NEW_RECORD' => '새로 만들기 Sudo Audit',
  'LNK_LIST' => '보기 Sudo Audit',
  'LNK_IMPORT_SA_SUDOAUDIT' => 'Import Sudo Audit',
  'LBL_SEARCH_FORM_TITLE' => '검색 Sudo Audit',
  'LBL_HISTORY_SUBPANEL_TITLE' => '연혁보기',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => '활동내역',
  'LBL_SA_SUDOAUDIT_SUBPANEL_TITLE' => 'Sudo Audit',
  'LBL_NEW_FORM_TITLE' => '신규 Sudo Audit',
  'LNK_IMPORT_VCARD' => 'Import Sudo Audit vCard',
  'LBL_IMPORT' => 'Import Sudo Audit',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Sudo Audit record by importing a vCard from your file system.',
  'LBL_MODULE_ID' => 'Module ID',
  'LBL_CREATED_BY_USER' => 'Created by user',
  'LBL_CREATED_BY_SUDO' => 'Created by sudo',
  'LBL_FIELD_NAME' => 'Field Name',
  'LBL_DATA_TYPE' => 'Data Type',
  'LBL_BEFORE_VALUE_STRING' => 'Before value string',
  'LBL_AFTER_VALUE_STRING' => 'After value string',
  'LBL_BEFORE_VALUE_TEXT' => 'Before value text',
  'LBL_AFTER_VALUE_TEXT' => 'After value text',
  'LBL_CREATED_BY_SUDO_USER_ID' => 'Created By Sudo (related User ID)',
  'sudo_parent_name' => 'Parent Record',
);