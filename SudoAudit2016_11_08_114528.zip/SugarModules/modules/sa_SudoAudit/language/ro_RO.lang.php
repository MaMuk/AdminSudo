<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/06_Customer_Center/10_Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Echipe',
  'LBL_TEAMS' => 'Echipe',
  'LBL_TEAM_ID' => 'Id Echipă',
  'LBL_ASSIGNED_TO_ID' => 'Atribuit ID Utilizator',
  'LBL_ASSIGNED_TO_NAME' => 'Atribuit lui',
  'LBL_TAGS_LINK' => 'Etichete',
  'LBL_TAGS' => 'Etichete',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Data creării',
  'LBL_DATE_MODIFIED' => 'Data Modificarii',
  'LBL_MODIFIED' => 'Modificat de',
  'LBL_MODIFIED_ID' => 'Modificat după Id',
  'LBL_MODIFIED_NAME' => 'Modificat după Nume',
  'LBL_CREATED' => 'Creat de',
  'LBL_CREATED_ID' => 'Creat de Id',
  'LBL_DOC_OWNER' => 'Proprietar document',
  'LBL_USER_FAVORITES' => 'Utilizatori cu setări favorite',
  'LBL_DESCRIPTION' => 'Descriere',
  'LBL_DELETED' => 'Şters',
  'LBL_NAME' => 'Nume',
  'LBL_CREATED_USER' => 'Creat de Utilizator',
  'LBL_MODIFIED_USER' => 'Modificat după Utilizator',
  'LBL_LIST_NAME' => 'Nume',
  'LBL_EDIT_BUTTON' => 'Editeaza',
  'LBL_REMOVE' => 'Eliminare',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modificat după Nume',
  'LBL_LIST_FORM_TITLE' => 'Sudo Audit Lista',
  'LBL_MODULE_NAME' => 'Sudo Audit',
  'LBL_MODULE_TITLE' => 'Sudo Audit',
  'LBL_MODULE_NAME_SINGULAR' => 'Sudo Audit',
  'LBL_HOMEPAGE_TITLE' => 'Al meu Sudo Audit',
  'LNK_NEW_RECORD' => 'Creează Sudo Audit',
  'LNK_LIST' => 'Vizualizare Sudo Audit',
  'LNK_IMPORT_SA_SUDOAUDIT' => 'Import Sudo Audit',
  'LBL_SEARCH_FORM_TITLE' => 'Cauta Sudo Audit',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'Vizualizare Istoric',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activitati',
  'LBL_SA_SUDOAUDIT_SUBPANEL_TITLE' => 'Sudo Audit',
  'LBL_NEW_FORM_TITLE' => 'Nou Sudo Audit',
  'LNK_IMPORT_VCARD' => 'Import Sudo Audit vCard',
  'LBL_IMPORT' => 'Import Sudo Audit',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Sudo Audit record by importing a vCard from your file system.',
  'LBL_MODULE_ID' => 'Module ID',
  'LBL_CREATED_BY_USER' => 'Created by user',
  'LBL_CREATED_BY_SUDO' => 'Created by sudo',
  'LBL_FIELD_NAME' => 'Field Name',
  'LBL_DATA_TYPE' => 'Data Type',
  'LBL_BEFORE_VALUE_STRING' => 'Before value string',
  'LBL_AFTER_VALUE_STRING' => 'After value string',
  'LBL_BEFORE_VALUE_TEXT' => 'Before value text',
  'LBL_AFTER_VALUE_TEXT' => 'After value text',
  'LBL_CREATED_BY_SUDO_USER_ID' => 'Created By Sudo (related User ID)',
  'sudo_parent_name' => 'Parent Record',
);