<?php
$mod_strings['LBL_LOGIN_AS'] = 'Login as';