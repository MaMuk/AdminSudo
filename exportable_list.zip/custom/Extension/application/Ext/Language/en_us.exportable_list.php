<?php
$app_strings['LBL_EXPORTABLE_LIST_DASHLET'] = 'Exportable List View';
$app_strings['LBL_EXPORTABLE_LIST_DASHLET_DESC'] = 'A list view dashlet that has an export option';
$app_strings['LBL_EXPORT_BUTTON'] = 'Export';